# POSTMORTEM.md
- v2.3 fixed compile/runtime stability issues (tuples, dispatcher, NTWindow, ClockEt)
- v2.4 integrated Pro logging + threading + subscriptions enhancements
