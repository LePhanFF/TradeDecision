# RUNTIME_NOTES.md
- UpdateHeader safe via UiThread.BeginInvoke()
- instruments.txt config file resolves symbols
- Logging to Output tab + rolling log file
