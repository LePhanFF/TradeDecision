Roadmap baseline V2.3 (NT8-compat); future: 30m OTF, morph engine, weighted confidence.
