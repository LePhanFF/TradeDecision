using System;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Helpers to convert continuous symbols (##-##) to a front-month contract and obtain an Instrument.
    /// </summary>
    internal static class DataSubscriptions
    {
        /// <summary>
        /// Returns a concrete future like "ES 12-25" for input "ES ##-##".
        /// If input is already concrete, it is returned unchanged.
        /// Uses a simple quarter-advance rule with a roll-window near the 3rd Friday.
        /// </summary>
        public static string ResolveFrontMonth(string symbol, DateTime? nowUtc = null)
        {
            symbol = (symbol ?? string.Empty).Trim();
            if (symbol.Length == 0) return symbol;
            if (!symbol.EndsWith("##-##", StringComparison.Ordinal))
                return symbol;

            string root = symbol.Replace("##-##", string.Empty).Trim();
            DateTime nowEt = TimeUtil.ToEastern((nowUtc ?? DateTime.UtcNow));

            int yearYY = nowEt.Year % 100;
            int[] quarters = { 3, 6, 9, 12 };
            int month = 0;
            foreach (var q in quarters)
            {
                if (nowEt.Month <= q) { month = q; break; }
            }
            if (month == 0) { month = 3; yearYY = (yearYY + 1) % 100; }

            // If we're within 7 days of the 3rd Friday of the quarter, advance one quarter
            var thirdFri = ThirdFriday(nowEt.Year, month);
            if ((thirdFri - nowEt.Date).TotalDays <= 7)
            {
                int idx = Array.IndexOf(quarters, month);
                if (idx == quarters.Length - 1) { month = 3; yearYY = (yearYY + 1) % 100; }
                else month = quarters[idx + 1];
            }

            return $"{root} {month:00}-{yearYY:00}";
        }

        /// <summary>
        /// Convenience: returns a NinjaTrader Instrument resolved from a potentially continuous string.
        /// </summary>
        public static Instrument GetInstrumentFromMaybeContinuous(string symbol)
        {
            try
            {
                string resolved = ResolveFrontMonth(symbol);
                var instrument = Instrument.GetInstrument(resolved);
                return instrument;
            }
            catch (Exception ex)
            {
                TpoLogger.Error($"GetInstrumentFromMaybeContinuous failed for '{symbol}': {ex.Message}");
                return null;
            }
        }

        private static DateTime ThirdFriday(int year, int month)
        {
            var d = new DateTime(year, month, 1);
            int fridays = 0;
            while (d.Month == month)
            {
                if (d.DayOfWeek == DayOfWeek.Friday && ++fridays == 3)
                    return d;
                d = d.AddDays(1);
            }
            return new DateTime(year, month, 15);
        }
    }
}