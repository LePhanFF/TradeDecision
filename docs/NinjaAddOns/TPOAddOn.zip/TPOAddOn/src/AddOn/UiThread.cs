using System;
using System.Windows;
using System.Windows.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Thread-safe helpers for WPF UI access within NinjaTrader add-ons.
    /// </summary>
    internal static class UiThread
    {
        /// <summary>
        /// Ensures <paramref name="action"/> runs on the UI thread that owns the WPF Dispatcher.
        /// Never throws if the dispatcher is missing; uses current dispatcher as a last resort.
        /// </summary>
        public static void OnUI(Action action)
        {
            if (action == null) return;
            Dispatcher d = Application.Current != null
                ? Application.Current.Dispatcher
                : Dispatcher.CurrentDispatcher;

            if (d.CheckAccess())
                action();
            else
                d.BeginInvoke(action);
        }

        /// <summary>
        /// Safely sets a DependencyProperty on any WPF object, marshaling to the correct dispatcher if required.
        /// </summary>
        public static void SafeSet(DependencyObject target, DependencyProperty dp, object value)
        {
            if (target == null || dp == null) return;

            Dispatcher d = target.Dispatcher ?? (Application.Current != null
                ? Application.Current.Dispatcher
                : Dispatcher.CurrentDispatcher);

            if (d.CheckAccess())
                target.SetValue(dp, value);
            else
                d.BeginInvoke(new Action(() => target.SetValue(dp, value)));
        }
    }
}