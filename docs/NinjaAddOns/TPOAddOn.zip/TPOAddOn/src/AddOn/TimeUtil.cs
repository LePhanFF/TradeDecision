using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class TimeUtil
    {
        /// <summary>
        /// Converts UTC to US Eastern Time (handles DST). Returns the input on failure.
        /// </summary>
        public static DateTime ToEastern(DateTime utc)
        {
            try
            {
                var tz = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                if (utc.Kind == DateTimeKind.Unspecified)
                    utc = DateTime.SpecifyKind(utc, DateTimeKind.Utc);
                else if (utc.Kind != DateTimeKind.Utc)
                    utc = utc.ToUniversalTime();
                return TimeZoneInfo.ConvertTimeFromUtc(utc, tz);
            }
            catch
            {
                return utc;
            }
        }
    }
}