using System;
using System.Windows.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Simple DispatcherTimer-based heartbeat that invokes a callback every interval with current ET time.
    /// Call Start() when your window is created, Stop()/Dispose() when closing.
    /// </summary>
    internal sealed class Heartbeat : IDisposable
    {
        private readonly DispatcherTimer _timer;
        private readonly Action<DateTime> _onTick;
        private bool _started;

        public Heartbeat(TimeSpan interval, Action<DateTime> onTick)
        {
            _onTick = onTick ?? (_ => { });
            _timer = new DispatcherTimer(DispatcherPriority.Background);
            _timer.Interval = interval <= TimeSpan.Zero ? TimeSpan.FromSeconds(1) : interval;
            _timer.Tick += (s, e) =>
            {
                var et = TimeUtil.ToEastern(DateTime.UtcNow);
                // Ensure consumer code runs on UI
                UiThread.OnUI(() => _onTick(et));
            };
        }

        public void Start()
        {
            if (_started) return;
            _timer.Start();
            _started = true;
            TpoLogger.Info($"Heartbeat started ({_timer.Interval.TotalSeconds:0.#}s).");
        }

        public void Stop()
        {
            if (!_started) return;
            _timer.Stop();
            _started = false;
            TpoLogger.Info("Heartbeat stopped.");
        }

        public void Dispose() => Stop();
    }
}