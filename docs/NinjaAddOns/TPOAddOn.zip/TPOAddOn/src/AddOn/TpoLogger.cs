using System;
using System.IO;
using NinjaTrader.Code;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Minimal logger that writes to the NinjaTrader Output tab and to a rolling log file.
    /// Safe for use anywhere; never throws.
    /// </summary>
    internal static class TpoLogger
    {
        private static readonly object _gate = new object();
        private static StreamWriter _writer;
        private static string _filePath;
        private static bool _initialized;

        public static void Init()
        {
            if (_initialized) return;
            try
            {
                string doc = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string logsDir = Path.Combine(doc, "NinjaTrader 8", "log");
                Directory.CreateDirectory(logsDir);
                _filePath = Path.Combine(logsDir, $"NinjaAddOnTPO_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                _writer = new StreamWriter(new FileStream(_filePath, FileMode.Create, FileAccess.Write, FileShare.Read))
                {
                    AutoFlush = true
                };
                _initialized = true;
                Info($"Logger initialized → {_filePath}");
            }
            catch (Exception ex)
            {
                Output.Process("[TPO] Logger initialization failed: " + ex, PrintTo.OutputTab1);
            }
        }

        public static void Info(string msg)  => Write("INFO ", msg);
        public static void Warn(string msg)  => Write("WARN ", msg);
        public static void Error(string msg) => Write("ERROR", msg);

        private static void Write(string level, string msg)
        {
            string line = $"[{DateTime.Now:HH:mm:ss.fff}] {level} {msg}";
            try
            {
                Output.Process("[TPO] " + line, PrintTo.OutputTab1);
                lock (_gate)
                {
                    _writer?.WriteLine(line);
                }
            }
            catch
            {
                // Never throw from logger
            }
        }
    }
}