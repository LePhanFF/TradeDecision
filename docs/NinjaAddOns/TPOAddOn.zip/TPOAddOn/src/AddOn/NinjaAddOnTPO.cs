// NinjaAddOnTPO.cs (v2.4) - logging, heartbeat, UI-thread helpers, instrument subscriptions
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Windows;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.AddOns;
using NinjaTrader.NinjaScript.AddOns.Ui;

namespace NinjaTrader.NinjaScript.AddOns
{
    public class NinjaAddOnTPO : AddOnBase
    {
        private const string VersionTag = "v2.4";
        private NTMenuItem menuItem;
        private bool isRunning = false;

        private DataEngine engine;
        private PeersModel peers;
        private JsonStore store;
        private Journal journal;
        private UiHostWindow ui;
        private Heartbeat hb;

        private readonly string baseDir = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "NinjaAddOn", "TPOAddon");
        private readonly string instrumentsCfg => System.IO.Path.Combine(baseDir, "instruments.txt");

        protected override void OnWindowCreated(Window w)
        {
            var cc = w as ControlCenter; if (cc == null) return;
            var newMenu = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem; if (newMenu == null) return;

            if (menuItem == null)
            {
                menuItem = new NTMenuItem
                {
                    Header = "NinjaAddOn TPO " + VersionTag,
                    Style = Application.Current.TryFindResource("MainMenuItem") as Style
                };
                menuItem.Click += (s, e) => { if (!isRunning) Start(); else Stop(); };
                newMenu.Items.Add(menuItem);
            }
        }

        protected override void OnWindowDestroyed(Window w)
        {
            var cc = w as ControlCenter; if (cc == null) return;
            if (menuItem != null)
            {
                var newMenu = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;
                if (newMenu != null && newMenu.Items.Contains(menuItem))
                    newMenu.Items.Remove(menuItem);
                menuItem = null;
            }
            if (isRunning) Stop();
        }

        private void Start()
        {
            try
            {
                Directory.CreateDirectory(baseDir);
                store   = new JsonStore(baseDir);
                journal = new Journal(baseDir);
                peers   = new PeersModel();

                // Create UI on UI thread
                UiThread.Invoke(() =>
                {
                    ui = new UiHostWindow();
                    ui.Show();
                });

                // Heartbeat (every 30s)
                hb = new Heartbeat(TimeSpan.FromSeconds(30), () => TpoLogger.Info("hb"));
                hb.Start();

                engine = new DataEngine();
                engine.BarComputed += OnBar;

                var instruments = ResolveInstruments();
                if (instruments.Count == 0)
                {
                    TpoLogger.Warn("No instruments resolved. Provide 'instruments.txt' with one symbol per line (e.g., 'NQ 12-25').");
                }
                else
                {
                    engine.Start(instruments);
                    TpoLogger.Info("Engine started for: " + string.Join(", ", instruments.Select(i => i.FullName)));
                }

                isRunning = true;
                UpdateHeader();
                TpoLogger.Info("AddOn Started " + VersionTag);
            }
            catch (Exception ex)
            {
                TpoLogger.Error("Start exception: " + ex);
            }
        }

        private void Stop()
        {
            try
            {
                isRunning = false;
                UpdateHeader();

                if (engine != null)
                {
                    engine.BarComputed -= OnBar;
                    engine.Stop();
                    engine = null;
                }

                if (hb != null) { hb.Dispose(); hb = null; }

                if (ui != null)
                {
                    UiThread.BeginInvoke(() => { try { ui.Close(); } catch { } });
                    ui = null;
                }

                TpoLogger.Info("AddOn Stopped.");
            }
            catch (Exception ex)
            {
                TpoLogger.Error("Stop exception: " + ex);
            }
        }

        private void UpdateHeader()
        {
            string h = isRunning ? "Stop NinjaAddOn TPO " + VersionTag : "NinjaAddOn TPO " + VersionTag;
            var mi = menuItem; if (mi == null) return;
            UiThread.BeginInvoke(() => { if (menuItem != null) menuItem.Header = h; });
        }

        private List<Instrument> ResolveInstruments()
        {
            var list = new List<Instrument>();
            string[] names = ReadInstrumentNames();

            foreach (var raw in names)
            {
                try
                {
                    string sym = DataSubscriptions.ResolveFrontMonth(raw, DateTime.UtcNow); // handle ##-##
                    var inst = Instrument.GetInstrument(sym);
                    if (inst != null) list.Add(inst); else TpoLogger.Warn("Instrument not found: " + sym);
                }
                catch (Exception ex)
                {
                    TpoLogger.Warn($"Resolve instrument failed for {raw}: {ex.Message}");
                }
            }
            return list;
        }

        private string[] ReadInstrumentNames()
        {
            // Defaults: front-months (edit as needed)
            var defaults = new string[] { "NQ 12-25", "ES 12-25", "YM 12-25" };
            try
            {
                if (File.Exists(instrumentsCfg))
                {
                    var raw = File.ReadAllLines(instrumentsCfg);
                    var cleaned = raw.Select(x => (x ?? string.Empty).Trim())
                                     .Where(x => x.Length > 0 && !x.StartsWith("#"))
                                     .Distinct(StringComparer.OrdinalIgnoreCase)
                                     .ToArray();
                    if (cleaned.Length > 0) return cleaned;
                }
            }
            catch (Exception ex)
            {
                TpoLogger.Warn("Could not read instruments.txt: " + ex.Message);
            }
            return defaults;
        }

        private void OnBar(object sender, BarComputedEventArgs e)
        {
            try
            {
                peers.ObserveBar(e.Symbol, e.H, e.L);
                var peersClosed = peers.SnapshotGapClosed();

                Classifier clf = new Classifier(0.25);
                CallDecision call = clf.ScoreCall(e.Opening, e.IB, e.Profile, e.Otf, peersClosed, "");

                // Simple journal + UI update
                journal.Append(
                    e.Symbol, e.Et,
                    string.Format(
                        "{0} {1} Bias={2} Day={3} Conf={4} IB[{5:0.00}/{6:0.00}] dPOC={7:0.00} VA[{8:0.00}/{9:0.00}/{10:0.00}] Singles:{11} OTF:{12}({13})",
                        e.Et.ToString("HH:mm"),
                        e.Symbol,
                        call.Bias,
                        call.DayType,
                        call.Confidence,
                        e.IB.High, e.IB.Low, e.Profile.Poc, e.Profile.Val, e.Profile.Poc, e.Profile.Vah,
                        (e.Profile.Singles != null ? e.Profile.Singles.Count : 0),
                        (e.Otf.Up ? "Up" : (e.Otf.Down ? "Down" : "-")),
                        e.Otf.Frame
                    )
                );

                UiThread.BeginInvoke(() =>
                {
                    if (ui != null)
                    {
                        ui.UpdateUi(
                            e.Et, e.Symbol, call.Bias, call.DayType, call.Confidence, "low",
                            new string[] { "POC " + e.Profile.Poc.ToString("0.00") + ", VA [" + e.Profile.Val.ToString("0.00") + "/" + e.Profile.Vah.ToString("0.00") + "]" },
                            new string[] { "Opening " + e.Opening.Type + ", IB[" + e.IB.High.ToString("0.00") + "/" + e.IB.Low.ToString("0.00") + "]" },
                            e.DPocTrail
                        );
                    }
                });
            }
            catch (Exception ex)
            {
                TpoLogger.Error("OnBar exception: " + ex);
            }
        }
    }
}
