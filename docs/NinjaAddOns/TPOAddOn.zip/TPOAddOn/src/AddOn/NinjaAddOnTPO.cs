using System;
using System.Text;
using System.Collections.Generic;
using System.Windows;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.AddOns.Core;
using NinjaTrader.NinjaScript.AddOns.Ui;
using NinjaTrader.Core;

namespace NinjaTrader.NinjaScript.AddOns
{
    public class NinjaAddOnTPO : AddOnBase
    {
        private const string VersionTag = "v9.4.3";
        private NTMenuItem menuItem; private bool isRunning=false;
        private DataEngine engine; private PeersModel peers; private JsonStore store; private Journal journal; private UiHostWindow ui;
        private System.Windows.Threading.Dispatcher Disp { get { return Application.Current != null ? Application.Current.Dispatcher : null; } }
        private readonly string[] instrumentNames = new string[]{ "ES ##-##", "NQ ##-##", "YM ##-##" };
        private readonly string baseDir = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "NinjaAddOn", "TPOAddon");

        protected override void OnWindowCreated(Window w)
        {
            ControlCenter cc = w as ControlCenter; if (cc == null) return;
            NTMenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem; if (newMenu == null) return;
            if (menuItem == null)
            {
                menuItem = new NTMenuItem{ Header="NinjaAddOn TPO " + VersionTag, Style = Application.Current.TryFindResource("MainMenuItem") as Style };
                menuItem.Click += delegate(object s, RoutedEventArgs e){ if(!isRunning) Start(); else Stop(); };
                newMenu.Items.Add(menuItem);
            }
        }

        protected override void OnWindowDestroyed(Window w)
        {
            ControlCenter cc = w as ControlCenter; if (cc == null) return;
            if (menuItem != null)
            {
                NTMenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;
                if (newMenu != null && newMenu.Items.Contains(menuItem)) newMenu.Items.Remove(menuItem);
                menuItem = null;
            }
            if (isRunning) Stop();
        }

        private void Start()
        {
            try
            {
                System.IO.Directory.CreateDirectory(baseDir);
                store   = new JsonStore(baseDir);
                journal = new Journal(baseDir);
                peers   = new PeersModel();

                var d = Disp;
                if (d != null)
                {
                    d.Invoke(new Action(() =>
                    {
                        var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); } ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); } ui.Owner = NTWindow.MainWindow; ui.Show(); }
                        ui.Owner = NTWindow.MainWindow;
                        ui.Show();
                    }));
                }
                else
                {
                    var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); } ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { var d = Application.Current != null ? Application.Current.Dispatcher : null;
if (d != null) d.Invoke(new Action(() => { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); }));
else { ui = new UiHostWindow(); ui.Owner = NTWindow.MainWindow; ui.Show(); } ui.Owner = NTWindow.MainWindow; ui.Show(); }
                    ui.Owner = NTWindow.MainWindow;
                    ui.Show();
                }

                engine = new DataEngine();
                engine.BarComputed += OnBar;

                List<Instrument> list = new List<Instrument>();
                for (int i=0;i<instrumentNames.Length;i++)
                {
                    Instrument inst = Instrument.GetInstrument(instrumentNames[i]);
                    if (inst!=null) list.Add(inst);
                    else SafeOut("[TPO] Missing instrument: " + instrumentNames[i]);
                }
                engine.Start(list);

                isRunning=true; UpdateHeader(); SafeOut("[TPO] Started " + VersionTag);
            }
            catch(Exception ex){ SafeOut("[TPO] Start exception: " + ex.Message); }
        }

        private void Stop()
        {
            try
            {
                isRunning=false; UpdateHeader();
                if(engine!=null){ engine.BarComputed-=OnBar; engine.Stop(); engine=null; }
                if(ui!=null){ ui.Dispatcher.BeginInvoke(new Action(delegate(){ ui.Close(); })); ui=null; }
                SafeOut("[TPO] Stopped.");
            }
            catch(Exception ex){ SafeOut("[TPO] Stop exception: " + ex.Message); }
        }

        private void UpdateHeader()
        {
            string h = isRunning? "Stop NinjaAddOn TPO " + VersionTag : "NinjaAddOn TPO " + VersionTag;
            var d = Disp; if (d!=null && !d.CheckAccess()) d.BeginInvoke(new Action(delegate(){ if(menuItem!=null) menuItem.Header=h; })); else if(menuItem!=null) menuItem.Header=h;
        }

        private void OnBar(object sender, BarComputedEventArgs e)
        {
            try
            {
                peers.ObserveBar(e.Symbol, e.H, e.L);
                Dictionary<string,bool> peersClosed = peers.SnapshotGapClosed();
                Classifier clf = new Classifier(0.25);
                CallDecision call = clf.ScoreCall(e.Opening, e.IB, e.Profile, e.Otf, peersClosed, "");

                journal.Append(e.Symbol, e.Et, string.Format("{0}  {1}  Bias={2}  Day={3}  Conf={4}  IB[{5:0.00}/{6:0.00}]  dPOC={7:0.00}  VA[{8:0.00}/{9:0.00}/{10:0.00}]  Singles:{11}  OTF:{12}({13})  Morph:low",
                    e.Et.ToString("HH:mm"), e.Symbol, call.Bias, call.DayType, call.Confidence, e.IB.High, e.IB.Low, e.Profile.Poc, e.Profile.Val, e.Profile.Poc, e.Profile.Vah, (e.Profile.Singles!=null?e.Profile.Singles.Count:0), (e.Otf.Up ? "Up" : (e.Otf.Down? "Down" : "-")), e.Otf.Frame));

                var inv = System.Globalization.CultureInfo.InvariantCulture;
                StringBuilder json = new StringBuilder(2048);
                json.Append("{"schemaVersion":"tpo.v9_4_3","type":"bar"");
                json.Append(","ts_utc":"").Append(e.Utc.ToString("yyyy-MM-ddTHH:mm:00Z")).Append(""");
                json.Append(","ts_et":"").Append(e.Et.ToString("yyyy-MM-ddTHH:mm:00")).Append(""");
                json.Append(","sessionId":"").Append(e.SessionId).Append(""");
                json.Append(","instrument":{"symbol":"").Append(e.Symbol).Append("","fullName":"").Append(e.FullName).Append(""}");
                json.Append(","bar":{"o":").Append(e.O.ToString(inv)).Append(","h":").Append(e.H.ToString(inv)).Append(","l":").Append(e.L.ToString(inv)).Append(","c":").Append(e.C.ToString(inv)).Append("}");
                json.Append(","context":{"rthPhase":"RTH","sinceOpenMin":").Append(e.IB.SinceOpenMin).Append(","gap":{"dir":"").Append(e.Opening.Dir).Append("","ticks":").Append(e.Opening.GapTicks).Append("},"opening":{"location":"").Append(e.Opening.Location).Append("","type":"").Append(e.Opening.Type).Append(""}}");
                json.Append(","ib":{"high":").Append((double.IsNaN(e.IB.High)?0:e.IB.High).ToString(inv)).Append(","low":").Append((double.IsNaN(e.IB.Low)?0:e.IB.Low).ToString(inv)).Append(","extensions":{"up":").Append(e.IB.ExtUpCount).Append(","down":").Append(e.IB.ExtDownCount).Append("}}");
                json.Append(","profile":{"tpo":{"poc":").Append(e.Profile.Poc.ToString(inv)).Append(","vah":").Append(e.Profile.Vah.ToString(inv)).Append(","val":").Append(e.Profile.Val.ToString(inv)).Append(","totalTpos":").Append(e.Profile.TotalTpos).Append("},");
                json.Append(""hvn":[");
                if (e.Profile.HVN != null){ for(int i=0;i<e.Profile.HVN.Count;i++){ if(i>0) json.Append(','); json.Append("{"price":").Append(e.Profile.HVN[i].Price.ToString(inv)).Append(","score":").Append(e.Profile.HVN[i].Score.ToString(inv)).Append("}"); } }
                json.Append("],"lvn":[");
                if (e.Profile.LVN != null){ for(int i=0;i<e.Profile.LVN.Count;i++){ if(i>0) json.Append(','); json.Append("{"price":").Append(e.Profile.LVN[i].Price.ToString(inv)).Append(","score":").Append(e.Profile.LVN[i].Score.ToString(inv)).Append("}"); } }
                json.Append("],"singles":[");
                if (e.Profile.Singles != null){ for(int i=0;i<e.Profile.Singles.Count;i++){ if(i>0) json.Append(','); json.Append("{"start":").Append(e.Profile.Singles[i].Start.ToString(inv)).Append(","end":").Append(e.Profile.Singles[i].End.ToString(inv)).Append("}"); } }
                json.Append("],"poor":{"high":").Append(e.Profile.PoorHigh ? "true":"false").Append(","low":").Append(e.Profile.PoorLow ? "true":"false").Append("}}");
                json.Append(","developing":{"dPoc":").Append(e.Profile.Poc.ToString(inv)).Append(","dPocTrail":[]}");
                json.Append(","structure":{"oneTimeframing":{"up":").Append(e.Otf.Up?"true":"false").Append(","down":").Append(e.Otf.Down?"true":"false").Append(","frame":"").Append(e.Otf.Frame).Append(""},"shape":"").Append(new Classifier(0.25).ShapeFromProfile(e.Profile)).Append("","morph":{"risk":"low","from":"","to":"","evidence":[]}}");
                double coh = 0.0; if (peersClosed != null && peersClosed.Count > 0){ int ok=0; foreach(var v in peersClosed.Values) if (v) ok++; coh = (double)ok / (double)peersClosed.Count; }
                json.Append(","peers":{"coherenceScore":").Append(coh.ToString(inv)).Append("}");
                json.Append(","call":{"bias":"").Append(call.Bias).Append("","dayType":"").Append(call.DayType).Append("","confidence":").Append(call.Confidence).Append(","reasons":[],"warnings":[]}");
                json.Append("}");

                string js = json.ToString();
                store.AppendBar(e.Symbol, e.Et, js);
                store.WriteLatest(e.Symbol, js);

                if (ui != null) ui.UpdateUi(e.Et, e.Symbol, call.Bias, call.DayType, call.Confidence, "low", new string[]{ "POC "+e.Profile.Poc.ToString("0.00") + ", VA ["+e.Profile.Val.ToString("0.00")+"/"+e.Profile.Vah.ToString("0.00")+"]" }, new string[]{ "Opening " + e.Opening.Type + ", IB["+e.IB.High.ToString("0.00")+"/"+e.IB.Low.ToString("0.00")+"]" }, e.DPocTrail);
            } catch(Exception ex){ SafeOut("[TPO] OnBar exception: " + ex.Message); }
        }

        private void SafeOut(string s)
        {
            var d=Disp;
            if(d!=null && !d.CheckAccess()) d.BeginInvoke(new Action(delegate(){ NinjaTrader.Code.Output.Process(s, PrintTo.OutputTab1); }));
            else NinjaTrader.Code.Output.Process(s, PrintTo.OutputTab1);
        }
    }
}
