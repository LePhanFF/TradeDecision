using System;

using NinjaTrader.NinjaScript.AddOns.Core;

namespace NinjaTrader.NinjaScript.AddOns.Core
{
    public static class ClockEt
    {
        public static DateTime NowEt()
        {
            try
            {
                return TimeZoneInfo.ConvertTime(DateTime.UtcNow,
                    TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
            }
            catch
            {
                return DateTime.Now;
            }
        }
    }
}
