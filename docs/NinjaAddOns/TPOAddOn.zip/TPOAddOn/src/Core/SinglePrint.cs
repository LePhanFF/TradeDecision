using System;

using NinjaTrader.NinjaScript.AddOns.Core;

namespace NinjaTrader.NinjaScript.AddOns.Core
{
    public class SinglePrint
    {
        public double Start { get; set; }
        public double End { get; set; }
    }
}
