using System;

using NinjaTrader.NinjaScript.AddOns.Core;

namespace NinjaTrader.NinjaScript.AddOns.Core
{
    public class Node
    {
        public double Price { get; set; }
        public double Score { get; set; }
    }
}
