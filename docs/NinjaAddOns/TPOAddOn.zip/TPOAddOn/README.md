TPOAddon FIX2 (AccessFix) — NT8-safe code, DpocPoint public, no modern C# features.
