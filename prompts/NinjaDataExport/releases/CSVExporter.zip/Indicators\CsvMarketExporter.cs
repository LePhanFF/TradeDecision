#region Using declarations
using System;
using System.IO;
using System.Text;
using System.Globalization;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
#endregion

// NinjaDataExport - CsvMarketExporter v2.2 (C#-5 compatible, flat folder)
// Exports historical + realtime bars to CSV with schema+header, EMA/RSI/ATR, OF VWAP ±1/2/3σ, and duplicate-avoidance.

namespace NinjaTrader.NinjaScript.Indicators
{
    // Keep enum at namespace scope (property grid visibility; avoids CS0246)
    public enum FilePartitionMode
    {
        SingleFile,
        Daily
    }

    public class CsvMarketExporter : Indicator
    {
        // -----------------------
        // User-configurable inputs
        // -----------------------
        [NinjaScriptProperty]
        [Display(Name = "Output Directory", Order = 1, GroupName = "Export")]
        public string OutputDirectory { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "File Partition Mode", Order = 2, GroupName = "Export")]
        public FilePartitionMode Partitioning { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Full Rebuild On Reload", Order = 3, GroupName = "Export",
            Description = "If true, deletes/rewrites the file from currently loaded bars each time the indicator loads.")]
        public bool FullRebuildOnReload { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Write UTC Timestamps", Order = 4, GroupName = "Export")]
        public bool UseUtcTimestamps { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Include VWAP Columns", Order = 5, GroupName = "VWAP")]
        public bool IncludeVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VWAP Resolution (Tick=best)", Order = 6, GroupName = "VWAP")]
        public bool UseTickVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use Chart Trading Hours (ETH/RTH)", Order = 7, GroupName = "VWAP",
            Description = "If true, use chart's Trading Hours. If false, override with template below.")]
        public bool UseChartTradingHours { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trading Hours Template (override)", Order = 8, GroupName = "VWAP",
            Description = "Examples: 'CME US Index Futures RTH' or 'CME US Index Futures ETH'")]
        public string TradingHoursTemplateName { get; set; }

        // -----------------------
        // Private state
        // -----------------------
        private static readonly ConcurrentDictionary<string, object> PathLocks =
            new ConcurrentDictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        private object FileLock
        {
            get
            {
                string key = _filePath != null ? _filePath : "default";
                return PathLocks.GetOrAdd(key, delegate (string _) { return new object(); });
            }
        }

        private string _filePath;
        private TradingHours _selectedTradingHours;
        private SessionIterator _sessionIterator;
        private DateTime? _lastWrittenTimestampLocal;   // stored in local time for comparison
        private readonly CultureInfo _ci = CultureInfo.InvariantCulture;
        private readonly UTF8Encoding _utf8NoBom = new UTF8Encoding(false);

        // Indicators
        private EMA _ema20, _ema50, _ema200;
        private RSI _rsi14;
        private ATR _atr14;
        private OrderFlowVWAP _vwapStd;  // standard resolution
        private OrderFlowVWAP _vwapTick; // tick resolution (needs 1-tick series)

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "CsvMarketExporter (NinjaDataExport v2.2)";
                Description = "Exports historical + realtime bars to CSV with schema+header, EMA/RSI/ATR, OF VWAP ±1/2/3σ.";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                IsSuspendedWhileInactive = false;

                // Defaults
                OutputDirectory = Path.Combine(Core.Globals.UserDataDir, "NinjaDataExport");
                Partitioning = FilePartitionMode.SingleFile;
                FullRebuildOnReload = false;
                UseUtcTimestamps = false;
                IncludeVWAP = true;
                UseTickVWAP = true;
                UseChartTradingHours = true;
                TradingHoursTemplateName = "CME US Index Futures RTH";
            }
            else if (State == State.Configure)
            {
                if (IncludeVWAP && UseTickVWAP)
                    AddDataSeries(BarsPeriodType.Tick, 1);
            }
            else if (State == State.DataLoaded)
            {
                _sessionIterator = new SessionIterator(Bars);

                // Trading Hours selection for VWAP reset logic
                _selectedTradingHours = Bars.TradingHours;
                if (!UseChartTradingHours)
                {
                    try { _selectedTradingHours = TradingHours.String2TradingHours(TradingHoursTemplateName); }
                    catch { _selectedTradingHours = Bars.TradingHours; }
                }

                // Init indicators
                _ema20 = EMA(20);
                _ema50 = EMA(50);
                _ema200 = EMA(200);
                _rsi14 = RSI(14, 3);      // classic smoothing = 3
                _atr14 = ATR(14);

                if (IncludeVWAP)
                {
                    _vwapStd  = OrderFlowVWAP(VWAPResolution.Standard, _selectedTradingHours,
                                              VWAPStandardDeviations.Three, 1, 2, 3);
                    if (UseTickVWAP)
                        _vwapTick = OrderFlowVWAP(BarsArray[0], VWAPResolution.Tick, _selectedTradingHours,
                                                  VWAPStandardDeviations.Three, 1, 2, 3);
                }

                Directory.CreateDirectory(OutputDirectory);
                _filePath = ResolveFilePathFor(DateTime.Now);

                if (FullRebuildOnReload && File.Exists(_filePath))
                    SafeDelete(_filePath);

                EnsureHeader(_filePath);

                if (!FullRebuildOnReload)
                    _lastWrittenTimestampLocal = TryReadLastTimestampLocal(_filePath);
            }
        }

        protected override void OnBarUpdate()
        {
            // Keep the OF VWAP in sync when using tick resolution (per Ninja docs pattern)
            if (IncludeVWAP && UseTickVWAP && BarsInProgress == 1)
            {
                // Update cached indicator on BIP=1 (tick series)
                _vwapTick.Update(_vwapTick.BarsArray[1].Count - 1, 1);
                return;
            }

            if (BarsInProgress != 0)
                return;

            // File rollover for Daily mode (flat folder; date in filename)
            if (Partitioning == FilePartitionMode.Daily)
            {
                string candidate = ResolveFilePathFor(Time[0]);
                if (!string.Equals(candidate, _filePath, StringComparison.OrdinalIgnoreCase))
                {
                    _filePath = candidate;
                    Directory.CreateDirectory(Path.GetDirectoryName(_filePath));
                    EnsureHeader(_filePath);
                    _lastWrittenTimestampLocal = TryReadLastTimestampLocal(_filePath);
                }
            }

            DateTime barTimeLocal = Time[0];
            if (_lastWrittenTimestampLocal.HasValue && barTimeLocal <= _lastWrittenTimestampLocal.Value)
                return; // already exported

            // Build columns
            string tsOut = UseUtcTimestamps
                ? barTimeLocal.ToUniversalTime().ToString("o", _ci)
                : barTimeLocal.ToString("yyyy-MM-dd'T'HH:mm:ss.fff", _ci);

            string instrument = GetInstrumentName();
            string period = BarsPeriod.BarsPeriodType.ToString() + "_" + BarsPeriod.Value.ToString(_ci);

            // Core OHLCV
            double o = Open[0], h = High[0], l = Low[0], c = Close[0];
            long v = Convert.ToInt64(Volume[0]);

            // Techs
            string ema20 = ToCsvNum(_ema20 != null ? _ema20[0] : double.NaN);
            string ema50 = ToCsvNum(_ema50 != null ? _ema50[0] : double.NaN);
            string ema200 = ToCsvNum(_ema200 != null ? _ema200[0] : double.NaN);
            string rsi14 = ToCsvNum(_rsi14 != null ? _rsi14[0] : double.NaN);
            string atr14 = ToCsvNum(_atr14 != null ? _atr14[0] : double.NaN);

            // VWAP + bands (std devs 1/2/3)
            string vwap = "", up1 = "", up2 = "", up3 = "", lo1 = "", lo2 = "", lo3 = "";
            if (IncludeVWAP)
            {
                try
                {
                    OrderFlowVWAP vRef = UseTickVWAP ? _vwapTick : _vwapStd;
                    if (vRef != null)
                    {
						vwap = ToCsvNum(vRef.Values[0][0]); // VWAP
						up1  = ToCsvNum(vRef.Values[1][0]); // +1σ
						up2  = ToCsvNum(vRef.Values[2][0]); // +2σ
						up3  = ToCsvNum(vRef.Values[3][0]); // +3σ
						lo1  = ToCsvNum(vRef.Values[4][0]); // -1σ
						lo2  = ToCsvNum(vRef.Values[5][0]); // -2σ
						lo3  = ToCsvNum(vRef.Values[6][0]); // -3σ
					}

                }
                catch (Exception ex)
                {
                    Print("[CsvMarketExporter] VWAP unavailable: " + ex.Message);
                    vwap = up1 = up2 = up3 = lo1 = lo2 = lo3 = "";
                }
            }

            // Session date (exchange trading day)
            DateTime tradingDay = _sessionIterator.GetTradingDay(barTimeLocal);
            string sessionDate = tradingDay.ToString("yyyy-MM-dd", _ci);

            // Compose CSV row (flat folder, header row fixed)
            string row = string.Join(",",
                tsOut,
                instrument,
                period,
                o.ToString("0.########", _ci),
                h.ToString("0.########", _ci),
                l.ToString("0.########", _ci),
                c.ToString("0.########", _ci),
                v.ToString(_ci),
                ema20, ema50, ema200,
                rsi14, atr14,
                vwap, up1, up2, up3, lo1, lo2, lo3,
                sessionDate
            );

            lock (FileLock)
            {
                using (var sw = new StreamWriter(_filePath, true, _utf8NoBom))
                    sw.WriteLine(row);
            }

            _lastWrittenTimestampLocal = barTimeLocal;
        }

        // -----------------------
        // Helpers
        // -----------------------
        private string ResolveFilePathFor(DateTime localBarTime)
        {
            string instr = GetInstrumentName();
            string tf = BarsPeriod.BarsPeriodType.ToString() + "_" + BarsPeriod.Value.ToString(_ci);
            string thLabel = UseChartTradingHours
                ? (Bars.TradingHours != null ? Bars.TradingHours.Name : "ChartTH")
                : (!string.IsNullOrEmpty(TradingHoursTemplateName) ? TradingHoursTemplateName : "TH_Override");
            string vwapRes = IncludeVWAP ? (UseTickVWAP ? "VWAP_Tick" : "VWAP_Std") : "VWAP_None";

            string baseName = Sanitize(instr) + "_" + tf + "_" + Sanitize(thLabel) + "_" + vwapRes;
            string fileName = (Partitioning == FilePartitionMode.Daily)
                ? baseName + "_" + localBarTime.ToString("yyyy-MM-dd", _ci) + ".csv"
                : baseName + ".csv";

            return Path.Combine(OutputDirectory, fileName);
        }

        private void EnsureHeader(string path)
        {
            if (File.Exists(path) && new FileInfo(path).Length > 0)
                return;

            Directory.CreateDirectory(Path.GetDirectoryName(path));

            using (var sw = new StreamWriter(path, false, _utf8NoBom))
            {
                // Row 1: schema comment (project contract)
                sw.WriteLine("#schema: NinjaDataExport/v1, delimiter=comma, headerRow=2, emptyFieldsAllowed=true, time=ISO8601"
                             + ", instrument=" + GetInstrumentName()
                             + ", timeframe=" + BarsPeriod.BarsPeriodType.ToString() + "_" + BarsPeriod.Value.ToString(_ci)
                             + ", tradingHours=" + (UseChartTradingHours
                                    ? (Bars.TradingHours != null ? Bars.TradingHours.Name : "Chart")
                                    : TradingHoursTemplateName)
                             + ", vwap=" + (IncludeVWAP ? (UseTickVWAP ? "tick" : "standard") : "none")
                             + ", tz=" + (UseUtcTimestamps ? "UTC" : "Local"));

                // Row 2: header (ALL columns on one line)
                sw.WriteLine("timestamp,instrument,period,open,high,low,close,volume,ema20,ema50,ema200,rsi14,atr14,vwap,vwap_upper1,vwap_upper2,vwap_upper3,vwap_lower1,vwap_lower2,vwap_lower3,session_date");
            }
        }

        private DateTime? TryReadLastTimestampLocal(string path)
        {
            try
            {
                if (!File.Exists(path) || new FileInfo(path).Length == 0)
                    return null;

                DateTime? last = null;
                bool headerSkipped = false;

                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, _utf8NoBom))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(line))
                            continue;
                        if (line.StartsWith("#"))
                            continue; // schema comment
                        if (!headerSkipped)
                        {
                            headerSkipped = true; // skip header row
                            continue;
                        }

                        int comma = line.IndexOf(',');
                        if (comma <= 0)
                            continue;

                        string ts = line.Substring(0, comma);
                        DateTimeStyles styles = DateTimeStyles.AssumeLocal;
                        if (ts.EndsWith("Z", StringComparison.OrdinalIgnoreCase))
                            styles = DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal;

                        DateTime dt;
                        if (DateTime.TryParse(ts, _ci, styles, out dt))
                            last = (styles == (DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal) || ts.EndsWith("Z", StringComparison.OrdinalIgnoreCase))
                                ? dt.ToLocalTime()
                                : dt;
                    }
                }
                return last;
            }
            catch (Exception ex)
            {
                Print("[CsvMarketExporter] Could not read last timestamp: " + ex.Message);
                return null;
            }
        }

        private void SafeDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (Exception ex) { Print("[CsvMarketExporter] Delete failed: " + ex.Message); }
        }

        private string Sanitize(string s)
        {
            if (string.IsNullOrEmpty(s)) return "UNKNOWN";
            char[] invalids = Path.GetInvalidFileNameChars();
            for (int i = 0; i < invalids.Length; i++)
                s = s.Replace(invalids[i], '_');
            return s;
        }

        private string GetInstrumentName()
        {
            if (Instrument == null) return "UNKNOWN";
            if (Instrument.MasterInstrument != null && !string.IsNullOrEmpty(Instrument.MasterInstrument.Name))
                return Instrument.MasterInstrument.Name;
            if (!string.IsNullOrEmpty(Instrument.FullName))
                return Instrument.FullName;
            return "UNKNOWN";
        }

        private string ToCsvNum(double x)
        {
            if (double.IsNaN(x) || double.IsInfinity(x))
                return ""; // empty field
            return x.ToString("0.########", _ci);
        }
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CsvMarketExporter[] cacheCsvMarketExporter;
		public CsvMarketExporter CsvMarketExporter(string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			return CsvMarketExporter(Input, outputDirectory, partitioning, fullRebuildOnReload, useUtcTimestamps, includeVWAP, useTickVWAP, useChartTradingHours, tradingHoursTemplateName);
		}

		public CsvMarketExporter CsvMarketExporter(ISeries<double> input, string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			if (cacheCsvMarketExporter != null)
				for (int idx = 0; idx < cacheCsvMarketExporter.Length; idx++)
					if (cacheCsvMarketExporter[idx] != null && cacheCsvMarketExporter[idx].OutputDirectory == outputDirectory && cacheCsvMarketExporter[idx].Partitioning == partitioning && cacheCsvMarketExporter[idx].FullRebuildOnReload == fullRebuildOnReload && cacheCsvMarketExporter[idx].UseUtcTimestamps == useUtcTimestamps && cacheCsvMarketExporter[idx].IncludeVWAP == includeVWAP && cacheCsvMarketExporter[idx].UseTickVWAP == useTickVWAP && cacheCsvMarketExporter[idx].UseChartTradingHours == useChartTradingHours && cacheCsvMarketExporter[idx].TradingHoursTemplateName == tradingHoursTemplateName && cacheCsvMarketExporter[idx].EqualsInput(input))
						return cacheCsvMarketExporter[idx];
			return CacheIndicator<CsvMarketExporter>(new CsvMarketExporter(){ OutputDirectory = outputDirectory, Partitioning = partitioning, FullRebuildOnReload = fullRebuildOnReload, UseUtcTimestamps = useUtcTimestamps, IncludeVWAP = includeVWAP, UseTickVWAP = useTickVWAP, UseChartTradingHours = useChartTradingHours, TradingHoursTemplateName = tradingHoursTemplateName }, input, ref cacheCsvMarketExporter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CsvMarketExporter CsvMarketExporter(string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			return indicator.CsvMarketExporter(Input, outputDirectory, partitioning, fullRebuildOnReload, useUtcTimestamps, includeVWAP, useTickVWAP, useChartTradingHours, tradingHoursTemplateName);
		}

		public Indicators.CsvMarketExporter CsvMarketExporter(ISeries<double> input , string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			return indicator.CsvMarketExporter(input, outputDirectory, partitioning, fullRebuildOnReload, useUtcTimestamps, includeVWAP, useTickVWAP, useChartTradingHours, tradingHoursTemplateName);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CsvMarketExporter CsvMarketExporter(string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			return indicator.CsvMarketExporter(Input, outputDirectory, partitioning, fullRebuildOnReload, useUtcTimestamps, includeVWAP, useTickVWAP, useChartTradingHours, tradingHoursTemplateName);
		}

		public Indicators.CsvMarketExporter CsvMarketExporter(ISeries<double> input , string outputDirectory, FilePartitionMode partitioning, bool fullRebuildOnReload, bool useUtcTimestamps, bool includeVWAP, bool useTickVWAP, bool useChartTradingHours, string tradingHoursTemplateName)
		{
			return indicator.CsvMarketExporter(input, outputDirectory, partitioning, fullRebuildOnReload, useUtcTimestamps, includeVWAP, useTickVWAP, useChartTradingHours, tradingHoursTemplateName);
		}
	}
}

#endregion
